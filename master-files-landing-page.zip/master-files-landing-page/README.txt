Fonts can be found at https://fonts.google.com/?query=mon&selection.family=Montserrat

Icons can also be found at https://fontawesome.com/